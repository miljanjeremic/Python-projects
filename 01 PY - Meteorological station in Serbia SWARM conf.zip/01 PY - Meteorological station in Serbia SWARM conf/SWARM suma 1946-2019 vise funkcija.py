import pandas as pd
import numpy as np

import statistics

data = pd.read_csv("1946-2019 final sve.csv")
#df = pd.read_csv(r"1946-2019 final sve.csv", sep=',').round((.sum()/74),1)
print(data.head(5))

#define function to calculate cv
cv = lambda x: np.std(x, ddof=1) / np.mean(x) * 100
# this function works similar to variation()
#cv = lambda x: np.std(x) / np.mean(x)

df = pd.read_csv(r"1946-2019 final sve.csv", sep=',').sum()/74
#df2 = np. mean(df)
#df4 = statistics.stdev(df)
#df3 = data.StdDev(df)
df3 = data.std(axis=0)
dfcv = data.apply(cv)

  

#dfstdev = [round(q, 2) for q in quantile(data, n=10)]
#dfstdev = df.quantile(0.5, numeric_only=False)
#dfstdev = data.quantile(0.5, axis=0)
#print(data.quantile(0.5,axis=0))
df1 = df.round(1)
df3 = df3.round(1)
dfcv = dfcv.round(1)
#df2 = df2.round(2)
#df3 = df2.round(2)


print(df1)
#print(df2)
#print(df3)
print(df3)
print(dfcv)

#print(df4)
#dfsve = [df1, df3, dfcv]
#print(dfsve)
#result = pd.concat(dfsve)
result = pd.concat([df1, df3, dfcv], axis=1)
print(result)
#df4 = pd.DataFrame(name_dict)


#df1.round(2)
result.to_csv(r'SWARM_sum2.csv')
#df2.to_csv()

