import pandas as pd
import numpy as np
#data = pd.read_csv("1946-2019 final sve.csv")
#df = pd.read_csv(r"1946-2019 final sve.csv", sep=',').round((.sum()/74),1)
df = pd.read_csv(r"1946-2019 final sve.csv", sep=',').sum()/74
df1 = df.round(2)
#df1.round(2)
df1.to_csv(r'SWARM_sum.csv')


