import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.api import VAR

import matplotlib.pyplot as plt

data = pd.read_csv("1946-2019 final sve.csv")
#data.index = pd.DatetimeIndex(data['Godina'])
data_use = data[['Palic','Loznica','Nis', 'Vranje', 'Cuprija']]

print(data_use.head(10))
'''
data['Nis'].plot(title = 'Nis', color = 'blue')
data['Palic'].plot(title = 'Palic', color = 'green')
data['Loznica'].plot(title = 'Loznica', color = 'orange')
data['Vranje'].plot(title = 'Vranje', color = 'red')
#data['Cuprija'].plot(title = 'Cuprija', color = 'purple')
data['Cuprija'].plot(title = 'Svi gradovi', color = 'purple')
'''


#fig = plt.figure()
#fig.set_size_inches(8, 8)
#ax = fig.add_axes([0.15,0.2,0.7,0.7]) 

#data['Palic'].plot(title = 'Palic', color = 'green')
y = data['Palic']
x = data['Godina']

plt.plot(x, y, color = 'green')
plt.xlim(1946, 2019)
plt.ylim(200, 1200)
#plt.show()
plt.xlabel('Year')
plt.ylabel('Precipitation (mm)')

# giving a title to my graph
plt.title('Palic ')

#plt.xlim([1946,2019])
#plt.ylim([200,1200])

# show a legend on the plot
plt.legend()
plt.show()


