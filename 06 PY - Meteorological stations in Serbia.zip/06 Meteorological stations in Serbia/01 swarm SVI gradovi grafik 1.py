import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.api import VAR

import matplotlib.pyplot as plt

data = pd.read_csv("1946-2019 final sve.csv")
#data.index = pd.DatetimeIndex(data['Godina'])
data_use = data[['Palic','Loznica','Nis', 'Vranje', 'Cuprija']]


print(data_use.head(10))



data['Nis'].plot(title = 'Nis', color = 'blue')
data['Palic'].plot(title = 'Palic', color = 'green')
data['Loznica'].plot(title = 'Loznica', color = 'orange')
data['Vranje'].plot(title = 'Vranje', color = 'red')
#data['Cuprija'].plot(title = 'Cuprija', color = 'purple')
data['Cuprija'].plot(title = 'Svi gradovi', color = 'purple')
plt.xlim(1946, 2019)
plt.ylim(200, 1200)
'''
data['Cuprija'].plot(title = 'Cuprija', color = 'purple', label = 'Cuprija')
plt.axis(xmin=1946, xmax=2019, ymin=200, ymax=1000)
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
plt.show()

data['Nis'].plot(title = 'Nis', color = 'blue', label = "Nis")
plt.axis(xmin=1946, xmax=2019, ymin=200, ymax=1000)
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
plt.show()

data['Vranje'].plot(title = 'Vranje', color = 'red', label = "Vranje")
plt.axis(xmin=1946, xmax=2019, ymin=200, ymax=1000)
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
plt.show()

data['Palic'].plot(title = 'Palic', color = 'green', label = "Palic")
plt.axis(xmin=1946, xmax=2019, ymin=200, ymax=1000)
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
plt.show()

data['Loznica'].plot(title = 'Loznica', color = 'orange', label = "Loznica")
plt.axis(xmin=1946, xmax=2019, ymin=200, ymax=1000)
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
plt.show()

#plt.ylim(200,1200)
#plt.xlim(1946,2019)
'''
plt.xlabel('1946 - 2019 year')
plt.ylabel('Precipitation (mm)')
#plt.show()

# giving a title to my graph
plt.title('Meteorological station in Serbia ')
  
# show a legend on the plot
plt.legend()
plt.show()

# compute changes
data_ret = np.log(data_use).diff().dropna()
# construct model
model = VAR(data_use)
#model = VAR(data)


# Fit model using 8 lags
results = model.fit(8)
results.summary()

results.plot_acorr()

lag_order = results.k_ar
# forecast 8 periods foreward
results.forecast(data_ret.values[-lag_order:],8)

results.plot_forecast(10)

irf = results.irf(10)
irf.plot(orth=False)

irf.plot_cum_effects(orth=False)
