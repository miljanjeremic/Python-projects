# plot "Population" vs "Employed"
from pandas import read_csv
from matplotlib import pyplot
import csv
import pandas as pd

'''
with open("mat.csv", "r") as csv_file:
    csv_reader = csv.reader(csv_file) #, delimiter=',')
    for lines in csv_reader:
      print(lines[1])
'''
'''
from pandas import read_excel
# find your sheet name at the bottom left of your excel file and assign 
# it to my_sheet 
my_sheet = 'Sheet1' # change it to your sheet name
file_name = 'mat.xlsx' # change it to the name of your excel file
df = pd.read_excel(file_name, index_col=0) #sheet_name = my_sheet)
print(df.head()) # shows headers with top 5 rows
'''
'''
file = 'mat.xlsx'
xl = pd.read_excel(file)
print(xl.sheet_names)
df1 = xl.parse('Sheet1')
print(df1.head())
'''
'''
df = pd.read_excel (r'mat.xlsx', sheet_name='Sheet1')
'''

names = ['x','Y']
df = pd.read_csv('matematika.csv', usecols=['x','Y'])
# X = dataset.iloc[:,-1:-4].values
data = df.values
x, y = data[:, 0], data[:, 1]
#x = df[['x']]
print(x)
#y = dataset.iloc[:, -5].values
#y = df[['Y']]
print(y)

# load the dataset
#url = 'https://raw.githubusercontent.com/jbrownlee/Datasets/master/longley.csv'
'''
col_list = ['X', 'Y']
dataframe = read_csv("mat.csv") # usecols=col_list) #, header=None)
'''
#url = 'https://raw.githubusercontent.com/jbrownlee/Datasets/master/longley.csv'
#dataframe = read_csv(url, header=None)
'''
data = dataframe.values

# choose the input and output variables
# x, y = data[:, 4], data[:, -1]

x = data[1]
print(x)
y = data[2]
print(y)
'''
# plot input vs output
pyplot.scatter(x, y)
pyplot.show()

