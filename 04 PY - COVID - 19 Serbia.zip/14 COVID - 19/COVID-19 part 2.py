import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import plotly.express as px
# import theme

# %matplotlib inline

COVID_CONFIRMED_URL = 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_19-covid-Confirmed.csv'
covid_confirmed = pd.read_csv(COVID_CONFIRMED_URL)

COVID_DEATHS_URL = 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_19-covid-Deaths.csv'
covid_deaths = pd.read_csv(COVID_DEATHS_URL)

COVID_RECOVERED_URL = 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_19-covid-Recovered.csv'
covid_recovered = pd.read_csv(COVID_RECOVERED_URL)

print(covid_confirmed.shape)
print(covid_deaths.shape)
print(covid_recovered.shape)

covid_confirmed.head()


covid_confirmed_long = pd.melt(covid_confirmed,
                               id_vars=covid_confirmed.iloc[:, :4],
                               var_name='date',
                               value_name='confirmed')

covid_deaths_long = pd.melt(covid_deaths,
                               id_vars=covid_deaths.iloc[:, :4],
                               var_name='date',
                               value_name='deaths')

covid_recovered_long = pd.melt(covid_recovered,
                               id_vars=covid_recovered.iloc[:, :4],
                               var_name='date',
                               value_name='recovered')
covid_confirmed_long.shape

covid_confirmed_long.head()


covid_df = covid_confirmed_long
covid_df['deaths'] = covid_deaths_long['deaths']
covid_df['recovered'] = covid_recovered_long['recovered']
print(covid_df.shape)

covid_df.head()


covid_df['active'] = covid_df['confirmed'] - covid_df['deaths'] - covid_df['recovered']
print(covid_df.shape)

covid_df.head()


covid_df['Country/Region'].replace('Mainland China', 'China', inplace=True)
covid_df[['Province/State']] = covid_df[['Province/State']].fillna('')
covid_df.fillna(0, inplace=True)


covid_df.isna().sum().sum()


covid_df.to_csv('covid_df.csv', index=None)
pd.read_csv('covid_df.csv')


covid_df.head()

covid_countries_df = covid_df.groupby(['Country/Region', 'Province/State']).max().reset_index()

covid_countries_df


covid_countries_df = covid_countries_df.groupby('Country/Region').sum().reset_index()

covid_countries_df


covid_countries_df.drop(['Lat', 'Long'], axis=1, inplace=True)

covid_countries_df



top_10_confirmed = covid_countries_df.sort_values(by='confirmed', ascending=False).head(10)

top_10_confirmed


fig = px.bar(top_10_confirmed.sort_values(by='confirmed', ascending=True),
             x="confirmed", y="Country/Region",
             title='Confirmed Cases', text='confirmed',
             template='plotly_dark', orientation='h')

fig.update_traces(marker_color='#3498db', textposition='outside')

fig.show()



top_10_recovered = covid_countries_df.sort_values(by='recovered', ascending=False).head(10)

top_10_recovered

fig = px.bar(top_10_recovered.sort_values(by='recovered', ascending=True),
             x="recovered", y="Country/Region",
             title='Recovered Cases', text='recovered',
             template='plotly_dark', orientation='h')

fig.update_traces(marker_color='#2ecc71', textposition='outside')

fig.show()



top_10_deaths = covid_countries_df.sort_values(by='deaths', ascending=False).head(10)

top_10_deaths

fig = px.bar(top_10_confirmed.sort_values(by='deaths', ascending=True),
             x="deaths", y="Country/Region",
             title='Death Cases', text='deaths',
             template='plotly_dark', orientation='h')

fig.update_traces(marker_color='#e74c3c', textposition='outside')

fig.show()



covid_countries_df['mortality_rate'] = round(covid_countries_df['deaths'] / covid_countries_df['confirmed'] * 100, 2)

temp = covid_countries_df[covid_countries_df['confirmed'] > 100]

top_20_mortality_rate = temp.sort_values(by='mortality_rate', ascending=False).head(20)

top_20_mortality_rate


fig = px.bar(top_20_mortality_rate.sort_values(by='mortality_rate', ascending=True),
             x="mortality_rate", y="Country/Region",
             title='Mortality rate', text='mortality_rate',
             template='plotly_dark', orientation='h',
             width=700, height=600)

fig.update_traces(marker_color='#c0392b', textposition='outside')

fig.show()



covid_countries_date_df = covid_df.groupby(['Country/Region', 'date'], sort=False).sum().reset_index()
covid_countries_date_df


covid_US = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'US']

covid_US


covid_China = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'China']
covid_Italy = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'Italy']
covid_Germany = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'Germany']
covid_Spain = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'Spain']
#covid_Argentina = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'Argentina']

covid_SRBIJA = covid_countries_date_df[covid_countries_date_df['Country/Region'] == 'Serbia']




covid_no_China = covid_countries_date_df[covid_countries_date_df['Country/Region'] != 'China']

covid_no_China = covid_no_China.groupby('date', sort=False).sum().reset_index()

fig, ax = plt.subplots(figsize=(16, 6))

sns.lineplot(x=covid_US['date'], y=covid_US['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_China['date'], y=covid_China['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Italy['date'], y=covid_Italy['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Germany['date'], y=covid_Germany['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Spain['date'], y=covid_Spain['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_no_China['date'], y=covid_no_China['confirmed'], sort=False, linewidth=2)

plt.suptitle("COVID-19 per country cases over the time", fontsize=16, fontweight='bold', color='white')

plt.xticks(rotation=45)
plt.ylabel('Confirmed cases')

ax.legend(['China', 'Italy', 'Germany', 'Spain', 'Argentina', 'World except China'])

plt.show()



fig, ax = plt.subplots(figsize=(16, 6))
ax.set(yscale="log")
ax.yaxis.set_major_formatter(ticker.FuncFormatter(lambda y, _: '{:g}'.format(y)))

sns.lineplot(x=covid_US['date'], y=covid_US['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_China['date'], y=covid_China['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Italy['date'], y=covid_Italy['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Germany['date'], y=covid_Germany['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_Spain['date'], y=covid_Spain['confirmed'], sort=False, linewidth=2)
sns.lineplot(x=covid_no_China['date'], y=covid_no_China['confirmed'], sort=False, linewidth=2)

plt.suptitle("COVID-19 per country cases over the time", fontsize=16, fontweight='bold', color='white')
plt.title("(logarithmic scale)", color='white')

plt.xticks(rotation=45)
plt.ylabel('Confirmed cases')

ax.legend(['China', 'Italy', 'Germany', 'Spain', 'Argentina', 'World except China'])

plt.show()



def plot_country_global_info(country):
    country_info = covid_countries_df[covid_countries_df['Country/Region'] == country]
    
    country_info_long = country_info.melt(value_vars=['active', 'deaths', 'recovered'],
                                          var_name="status",
                                          value_name="count")

    country_info_long['upper'] = 'Confirmed cases'
    
    fig = px.treemap(country_info_long, path=["upper", "status"], values="count",
                     title=f"Total COVID-19 confirmed cases in {country}",
                     color_discrete_sequence=['#3498db', '#2ecc71', '#e74c3c'],
                     template='plotly_dark')

    fig.data[0].textinfo = 'label+text+value'

    fig.show()


def plot_country_cases_over_time(country, log):
    country_date_info = covid_countries_date_df[covid_countries_date_df['Country/Region'] == country]
    
    fig, ax = plt.subplots(figsize=(16, 6))

    if log:
        ax.set(yscale="log")
        ax.yaxis.set_major_formatter(ticker.FuncFormatter(lambda y, _: '{:g}'.format(y)))
        plt.title("(logarithmic scale)", color='white')

    sns.lineplot(x=country_date_info['date'], y=country_date_info['confirmed'], sort=False, linewidth=2)
    sns.lineplot(x=country_date_info['date'], y=country_date_info['deaths'], sort=False, linewidth=2)
    sns.lineplot(x=country_date_info['date'], y=country_date_info['recovered'], sort=False, linewidth=2)
    sns.lineplot(x=country_date_info['date'], y=country_date_info['active'], sort=False, linewidth=2)
                
    ax.lines[0].set_linestyle("--")

    plt.suptitle(f"COVID-19 cases in {country} over the time", fontsize=16, fontweight='bold', color='white')

    plt.xticks(rotation=45)
    plt.ylabel('Number of cases')

    ax.legend(['Confirmed', 'Deaths', 'Recovered', 'Active'])

    plt.show()

def plot_province_cases(country):
    covid_provinces_df = covid_df.groupby(['Province/State', 'Country/Region']).max().reset_index()
    
    country_provinces_info = covid_provinces_df[covid_provinces_df['Country/Region'] == country]
    
    has_provinces = country_provinces_info.shape[0] > 1
    
    if (has_provinces):
        country_info_long = country_provinces_info.melt(id_vars=['Province/State'],
                                                        value_vars=['active', 'deaths', 'recovered'],
                                                        var_name="status",
                                                        value_name="count")

        country_info_long['upper'] = 'Confirmed cases'

        fig = px.treemap(country_info_long, path=['upper', "Province/State", "status"],
                         values="count",
                         title=f"Number of COVID-19 confirmed cases per Province/State in {country}",
                         template='plotly_dark')
        
        fig.data[0].textinfo = 'label+text+value'

        fig.show()

def get_country_covid_info(country, log=False):
    plot_country_global_info(country)
    
    plot_country_cases_over_time(country, log)
    
    plot_province_cases(country)


get_country_covid_info('US')

get_country_covid_info('US', log=True)

get_country_covid_info('China')

get_country_covid_info('OTHER_COUNTRY')

