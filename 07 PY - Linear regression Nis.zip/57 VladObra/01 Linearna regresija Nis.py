# Uvoz pandas modula za manipulaciju nad podacima.
# Alias pd za pandas se koristi po konvenciji.
import pandas as pd

# Uvoz pyplot modula za vizuelizaciju podataka.
# Alias plt za pyplot se koristi po konvenciji.
import matplotlib.pyplot as plt

# Uvoz numpy modula za rad sa visedimenzionim nizovima.
# Alias np za numpy se koristi po konvenciji.
import numpy as np

# Mapa boja (colormap) za bojenje funkciju greske
from matplotlib import cm

# Obican model Linearne regresije
from sklearn.linear_model import LinearRegression

from mpl_toolkits.mplot3d import Axes3D # <--- This is important for 3d plotting 

# Citanje .csv fajla i kreiranje DataFrame-a od njega.
# Zaglavlje .csv fajla predstavlja imena kolona DataFrame-a.
data = pd.read_csv('1946-2019 final sve.csv')

# Ispis prvih 5 redova DataFrame-a
print(data.head())
#####
X = data.loc[:, ['Nis']]

y = data['Palic']
#y = y / 1000

plt.figure('Precipitation')
plt.scatter(X, y, s=23, c='red', marker='o', alpha=0.7,
edgecolors='black', linewidths=2, label='Stanice')
#####
plt.xlabel('Nis', fontsize=13)
plt.ylabel('Palic', fontsize=13)
plt.title('Precipitation in mm')
plt.legend()
plt.show()
#####
class LinearRegressionGradientDescent:
    def __init__(self):
        self.coeff = None
        self.features = None
        self.target = None
        self.mse_history = None

    def set_coefficients(self, *args):
        # Mapiramo koeficijente u niz oblika (n + 1) x 1
        self.coeff = np.array(args).reshape(-1, 1)
#####
    def cost(self):
        predicted = self.features.dot(self.coeff)
        s = pow(predicted - self.target, 2).sum()
        return (0.5 / len(self.features)) * s

    def predict(self, features):
        features = features.copy(deep=True)
        features.insert(0, 'Palic', np.ones((len(features), 1)))
        features = features.to_numpy()
        return features.dot(self.coeff).reshape(-1, 1).flatten()
#####

    def gradient_descent_step(self, learning_rate):
    # learning_rate - korak ucenja; dimenzije ((n + 1) x 1);
    # korak ucenja je razlicit za razlicite koeficijente
    # m - broj uzoraka
        predicted = self.features.dot(self.coeff)
        #####
        s = self.features.T.dot(predicted - self.target)
        gradient = (1. / len(self.features)) * s
        self.coeff = self.coeff - learning_rate * gradient
        return self.coeff, self.cost()
#####

    def perform_gradient_descent(self, learning_rate, num_iterations=100):
        # Istorija Mean-square error-a kroz iteracije gradijentnog spusta.
        self.mse_history = []
        for i in range(num_iterations):
            _, curr_cost = self.gradient_descent_step(learning_rate)
            self.mse_history.append(curr_cost)
        return self.coeff, self.mse_history
#####
    
    def fit(self, features, target):
        self.features = features.copy(deep=True)
        coeff_shape = len(features.columns) + 1
        self.coeff = np.zeros(shape=coeff_shape).reshape(-1, 1)
        self.features.insert(0, 'Palic', np.ones((len(features), 1)))
        # self.features - dimenzije (m x (n + 1))
        self.features = self.features.to_numpy()
        # self.target - dimenzije (m x 1)
        self.target = target.to_numpy().reshape(-1, 1)
#####
        
spots = 200
estates = pd.DataFrame(data=np.linspace(0, max(X['Nis']), num=spots))
lrgd = LinearRegressionGradientDescent()

# Kreiranje i obucavanje modela
#X = data.loc[:, ['Loznica']]
lrgd = LinearRegressionGradientDescent()
lrgd.fit(X, y)
learning_rates = np.array([[0.17], [0.0000475]]) #0.0000475
res_coeff, mse_history = lrgd.perform_gradient_descent(learning_rates, 20)

# Vizuelizacija modela
plt.figure(1)
line, = plt.plot(estates[0], lrgd.predict(estates), lw=5, c='red')
line.set_label('LRGD model')

# Kreiranje i obucavanje sklearn.LinearRegression modela
lr_model = LinearRegression()
lr_model.fit(X, y)

# Vizuelizacija modela
plt.scatter(X, y, s=23, c='red', marker='o', alpha=0.7,
edgecolors='black', linewidths=2, label='Stanice')
line, = plt.plot(estates[0], lr_model.predict(estates), lw=2, c='blue')
line.set_label('Ordinary LR model')
# Lokacija legende (gore levo)
plt.legend(loc='upper left')
plt.show()

#####
# Vizuelizacija MS_error funkcije kroz iteracije
# za model koji koristi gradijentni spust.
plt.figure('MS Error')
plt.plot(np.arange(0, len(mse_history), 1), mse_history)
plt.xlabel('Iteration', fontsize=13)
plt.ylabel('MS error value', fontsize=13)
plt.xticks(np.arange(0, len(mse_history), 2))
plt.title('Mean-square error function')
plt.tight_layout()
plt.legend(['MS Error'])
plt.show()
#####

spots = 100
c0, c1 = np.meshgrid(np.linspace(-50, 50, spots), np.linspace(0, 2, spots))
# Od visedimenzionih nizova pravimo jednodimenzione nizove
c0 = c0.flatten()
c1 = c1.flatten()
mse_values = []
for i in range(len(c0)):
    lrgd.set_coefficients(c0[i], c1[i])
    mse_values.append(lrgd.cost())
#####


fig = plt.figure('MSE hyperplane')
ax = plt.subplot(1, 1, 1, projection='3d')
surf = ax.plot_surface(c0.reshape(spots, spots), c1.reshape(spots, spots),
np.array(mse_values).reshape(spots, spots),cmap=cm.coolwarm)
min_mse_ind = mse_values.index(min(mse_values))
ax.scatter(c0[min_mse_ind], c1[min_mse_ind], mse_values[min_mse_ind],
c='r', s=250, marker='^')
fig.colorbar(surf, shrink=0.5)
ax.set_xlabel('c0')
ax.set_ylabel('c1')
ax.set_zlabel('mse')
plt.title('MSE error')
plt.tight_layout()
plt.show()
#####


# Testiranje predikcije oba modela nad jednim uzorkom
# price = c1 * area + c0
example_estate_sqm = 122
example_estate = pd.DataFrame(data=[example_estate_sqm])
lrgd.set_coefficients(res_coeff)
print(f'LRGD price for {example_estate_sqm}sqm house is '
f'{lrgd.predict(example_estate)[0]:.2f} thousand $')
print(f'LRSV c0: {lrgd.coeff.flatten()[0]:.2f}, '
f'c1: {lrgd.coeff.flatten()[1]:.2f}')
print(f'LR price for {example_estate_sqm}sqm house is '
f'{lr_model.predict(example_estate)[0]:.2f} thousand $')
print(f'LR c0: {lr_model.intercept_:.2f}, '
f'c1: {lr_model.coef_[0]:.2f}')
#####

lrgd.set_coefficients(res_coeff)
print(f'LRGD MSE: {lrgd.cost():.2f}')
c = np.concatenate((np.array([lr_model.intercept_]), lr_model.coef_))
lrgd.set_coefficients(c)
print(f'LR MSE: {lrgd.cost():.2f}')
lrgd.set_coefficients(res_coeff)
#####

data_test = pd.read_csv('1946-2019 final sve.csv')
X = data_test[['Nis']]
y = data_test['Palic'] #/1000

# da bi se postavili LRGD koeficijenti i izracunao LR score.
lr_coef_ = lr_model.coef_
lr_int_ = lr_model.intercept_
lr_model.coef_ = lrgd.coeff.flatten()[1:]
lr_model.intercept_ = lrgd.coeff.flatten()[0]
print(f'LRGD score: {lr_model.score(X, y):.2f}')
# Restauriraju se koeficijenti LR modela
lr_model.coef_ = lr_coef_
lr_model.intercept_ = lr_int_
print(f'LR score: {lr_model.score(X, y):.2f}')





